1. It uses below tech stacks - 
PHP
HTML
Ajax
jquery
bootstrap
css
mysql

2. database file is todoapp.sql

3. user detai for login
a. admin
abcd12345@gmail.com
12345

b. user
b@gmail.com
12345
aaa@gmail.com
12345
aaa@gmail.com
12345
  
