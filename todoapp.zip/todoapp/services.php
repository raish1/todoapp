<?php require"header.php"; ?>

<!-- ======= Services Section ======= -->
    <div id="services" class="services-area area-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
		  <br>
            <div class="section-headline services-head text-center">
              <h2>Our Services</h2>
            </div>
          </div>
        </div>
		<div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
		  <br>
            <div class="">
              <h2>REASONS WHY WE ARE YOUR BEST CHOICE</h2>
            </div>
          </div>
		  <div class="col-md-12 col-sm-12 col-xs-12">
		  <br>
            <div class="">
              <p>
				We don’t just build, but we make it lively.
			</p>
			<p>
				We don’t just drive the traffic, but also help you convert it to paying customers.
				</p>
				<p>
				We make our clients outshine their competitors.
				 </p>
				 <p>
				Client satisfaction is our priority. At InnogenX, we deliver the best so that you can hit the bull’s eye in the digital marketing zone.
				 </p>
				 <p>
				We take into consideration various factors and develop websites that one can access on different devices.
				 </p>
				 <p>
				Be it any industry, we are always focused on adding value to our clients and are all ears to your needs.
				</p>
            </div>
          </div>
        </div>
		
		
    <!-- ======= Blog Section ======= -->
    <div id="blog" class="blog-area">
      <div class="blog-inner area-padding">
        <div class="blog-overly"></div>
        <div class="container ">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="section-headline text-center">
                <h2>LET’S CHECK OUR SERVICES</h2>
              </div>
            </div>
          </div>
          <div class="row">
            <!-- Start Left Blog -->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="single-blog">
                <div class="single-blog-img">
					<img src="assets/img/blog/1.jpg" alt="">
                </div>
                <br>
                <div class="blog-text">
                  <h4>
                    Web Site Development and Maintenance
                  </h4>
                  <p>
                    Innogenx has full time certified webmasters with extensive experience who develop sophisticated, easy to navigate websites. We emphasize attractive, informative, and user-friendly designs that fascinate the visitors, and they want to explore and know more.
                  </p>
                </div>
                
              </div>
              <!-- Start single blog -->
            </div>
            <!-- End Left Blog-->
            <!-- Start Left Blog -->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="single-blog">
                <div class="single-blog-img">
                  <img src="assets/img/blog/2.jpg" alt="">
                </div>
                <br>
                <div class="blog-text">
                  <h4>
                    E-Commerce
                  </h4>
                  <p>
                    We build agile and scalable E-commerce websites. We customize them as per your needs. At Innogenx, we understand that for any e-commerce venture to succeed, it needs to be backed by a competent management team, good post-sales services, a well-organized business structure, network infrastructure, and a secured, well-designed website.
                  </p>
                </div>
              </div>
              <!-- Start single blog -->
            </div>
            <!-- End Left Blog-->
            <!-- Start Right Blog-->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="single-blog">
                <div class="single-blog-img">
					<img src="assets/img/blog/3.jpg" alt="">
                </div>
                
                <br>
                <div class="blog-text">
                  <h4>
                    Application Development
                  </h4>
                  <p>
                    Mobile applications are a massive growth opportunity for businesses today. We create mobile apps with an attractive user interface providing a seamless experience to your clients when they engage with your brand.
                  </p>
                </div>
              </div>
            </div>
            <!-- End Right Blog-->
          </div>
        </div>
      </div>
    </div><!-- End Blog Section -->

        
      </div>
    </div><!-- End Services Section -->

<?php require"footer.php"; ?>