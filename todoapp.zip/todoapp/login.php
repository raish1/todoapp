<?php 
//session_start();
require"header.php"; 
require"db.php"; 
$loginFail = $result= '';

if(isset($_POST['login'])){
	$email 		= $_POST["email"];
	$password 	= base64_encode($_POST["password"]);

	$sql 		= "SELECT id, name, email, password FROM user Where email='$email' and password='$password'";
	$data 		= mysqli_query($conn,$sql);
	$result 	= mysqli_num_rows($data);
	$row 		= mysqli_fetch_array($data);
	
	if($result==1){
		$_SESSION['name'] = $row['name'];
		$_SESSION['email'] = $row['email'];
		header("location: welcome.php");
	}else{
		$loginFail = "login is failed";
	}
}

?>

    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
       <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                 <div class="comment-respond">
                    <h3 class="comment-reply-title">Login </h3>
                    <span class="email-notes">Required fields are marked *</span>
                    <form action="login.php" method='post'>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Email *</p>
							<input type="email" name="email" placeholder="email" required>
							</div>
						</div>
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Password *</p>
							  <input type="password" name="password" placeholder="password" required >
							</div>
						</div>
						<div class="row">	
							<div class="col-lg-6 col-md-6 col-sm-6 comment-form-comment">
							  <input type="submit" name='login' value="Login" />
							</div>
						</div>
                    </form>
					<br>
					
					<span class=""><?php if($result!=1){ echo $loginFail;} ?></span>
                  </div>
                
                <!-- single-blog end -->
              </div>
            </div> 
          
        </div>
      </div>
    


<?php require"footer.php"; ?>