<?php 
//session_start();
require"header.php"; 
require"db.php"; 
$name=$email=$mobile=$gender=$department=$city=$address=$password=$role=$user_id="";
$sql 		= "SELECT id, name FROM department";
$data 		= mysqli_query($conn,$sql);
$sql        ="SELECT id,role FROM user_role";
$result 	= mysqli_query($conn,$sql);

if(!isset($_POST['submit'])){
	$user_id =$_GET['user_id'];
	$sql="SELECT*FROM user Where id='".$user_id."'";
	$query_user = mysqli_query($conn,$sql);
	$result_user = mysqli_fetch_array($query_user);
	$name = $result_user['name'];
	$email = $result_user['email'];
	$mobile = $result_user['mobile'];
	$gender = $result_user['gender'];
	$department = $result_user['department'];
	$city = explode(",",$result_user['city']);
	$address = $result_user['address'];
	$password = base64_decode($result_user['password']);
	$role = $result_user['role'];
	mysqli_close($conn);
}
if(isset($_POST['submit'])){
	//$user_id = $_GET['user_id'];
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$gender = $_POST['gender'];
	$department = $_POST['department'];
	$city = implode(",",$_POST['city']);
	$address = $_POST['address'];
    $password = base64_encode($_POST['password']);
	$role = $_POST['role'];
	$user_edit_id = $_POST['user_edit_id'];
	//echo $user_edit_id;exit();
	if($name!=""){
		$sql = "UPDATE user SET name='".$name."',email='".$email."',mobile='".$mobile."',gender='".$gender."',department='".$department."',city='".$city."',address='".$address."',role='".$role."',password='".$password."' Where id='".$user_edit_id."'";
		//echo $sql;exit();
			    if($conn->query($sql)){
					header("location: welcome.php");
				}else{
					echo "error".$sql."</br>".$conn->error;
				}
				$conn->close();
	}else{
		echo "data is not founded";
	}
}

?>

    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
       <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                 <div class="comment-respond">
                    <h3 class="comment-reply-title">Update Form </h3>
                    <span class="email-notes">Required fields are marked *</span>
                    <form action="editUser.php" method='post'>
					<input  class=""type="hidden" name="user_edit_id" id="user_edit_id" value=<?php echo $user_id;?>>
					    <div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Name *</p>
							<input type="text" name="name" placeholder="name" value="<?php echo $name;?>">
							</div>
							
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Email *</p>
							<input type="email" class='emailCheck' id='email' name="email" placeholder="email" value="<?php echo $email;?>" required>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="email_response" ></div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Mobile *</p>
							  <input type="text" name="mobile" placeholder="Number" value="<?php echo $mobile;?>">
							</div>
							
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Gender *</p>
							  <input type="radio" name="gender" value="male"<?php if($gender=="male"){ echo "checked";}?>>&nbsp;&nbsp; <b>Male</b>
							  <input type="radio" name="gender" value="female"<?php if($gender=="female"){ echo "checked";}?>>&nbsp;&nbsp; <b>Female</b>
							</div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Department *</p>
								<select name="department" class='selectboxcss'> 
							   <option value='1' <?php if($department==1){ echo "selected";}?>>Development</option>
							   <option value='2' <?php if($department==2){ echo "selected";}?>>Design</option>
							   <option value='3' <?php if($department==3){ echo "selected";}?>>e-commerce</option>
							   <option value='4' <?php if($department==4){ echo "selected";}?>>Digital Marketing</option>
							   </select>
							</div>
							
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								   <p>City *</p>
								<label class="checkbox-inline"><input type="checkbox" name="city[]" value="kanpur"<?php if(in_array("kanpur",$city)){ echo "checked";}?>>&nbsp;&nbsp; kanpur</label>
								<label class="checkbox-inline"><input type="checkbox" name="city[]" value="lucknow"<?php if(in_array("lucknow",$city)){ echo "checked";}?>>&nbsp;&nbsp; lucknow</label>
								<label class="checkbox-inline"><input type="checkbox" name="city[]" value="patna"<?php if(in_array("patna",$city)){ echo "checked";}?>>&nbsp;&nbsp; patna</label>
								<label class="checkbox-inline"><input type="checkbox" name="city[]" value="bengluru"<?php if(in_array("bengluru",$city)){ echo "checked";}?>>&nbsp;&nbsp; bengluru</label>
							</div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Password *</p>
							  <input type="password" name="password" placeholder="password" value="<?php echo $password;?>">
							</div>
						
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Role *</p>
								<select name="role" class='selectboxcss'>
								   <option value="1"<?php if($role==1){ echo "selected";}?>>admin</option>
								   <option value="2"<?php if($role==2){ echo "selected";}?>>user</option>
								   </select>
							</div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Address *</p>
							   <textarea  name="address"  rows="3" cols="101" placeholder="Enter Address"><?php echo htmlspecialchars($address);?></textarea>
							</div>
						</div>
						
						<div class="row">	
							<div class="col-lg-6 col-md-6 col-sm-6 comment-form-comment">
							  <input type="submit" name='submit' value="Update" />
							</div>
						</div>
                    </form>
					<br>
                  </div>
                
                <!-- single-blog end -->
              </div>
            </div> 
        </div>
      </div>
    

<?php require"footer.php"; ?>