<?php 
//session_start();
require"header.php"; 
require"db.php"; 

$sql 		= "SELECT id, name FROM department";
$data 		= mysqli_query($conn,$sql);
$sql        ="SELECT id,role FROM user_role";
$result 	= mysqli_query($conn,$sql);


if(isset($_POST['login'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$mobile = $_POST['mobile'];
	$gender = $_POST['gender'];
	$department = $_POST['department'];
	$city = implode(",",$_POST['city']);
	$address = $_POST['address'];
    $password = base64_encode($_POST['password']);
	$role = $_POST['role'];
	if($name!=""){
		$sql = "INSERT INTO user(`name`,`email`,`mobile`,`gender`,`department`,`city`,`address`,`password`,`role`)
		        VALUES('$name','$email','$mobile','$gender','$department','$city','$address','$password','$role')";
	 
				if($conn->query($sql)){
					header("location: login.php");
				}else{
					echo "error".$sql."</br>".$conn->error;
				}
				$conn->close();
	}else{
		echo "data is not founded";
	}
}

?>

    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
       <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                 <div class="comment-respond">
                    <h3 class="comment-reply-title">Sign Up </h3>
                    <span class="email-notes">Required fields are marked *</span>
                    <form action="signup.php" method='post'>
					    <div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Name *</p>
							<input type="text" name="name" placeholder="name" required>
							</div>
							
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Email *</p>
							<input type="email" class='emailCheck' id='email' name="email" placeholder="email" required>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12" id="email_response" ></div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Mobile *</p>
							  <input type="text" name="mobile" placeholder="Number" >
							</div>
							
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Gender *</p>
							  <input type="radio" name="gender" value="male">&nbsp;&nbsp; <b>Male</b>
							  <input type="radio" name="gender" value="female">&nbsp;&nbsp; <b>Female</b>
							</div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Department *</p>
								<select name='department' class='selectboxcss'>
									<?php  
										while($row_list=mysqli_fetch_assoc($data)){ ?>  
										<option value="<?php echo $row_list['id']; ?>">
											<?php echo $row_list['name'];?>  
										</option>  
									<?php } ?>  
								</select>
							</div>
							
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
								   <p>City *</p>
								<label class="checkbox-inline"><input type="checkbox" name="city[]"value="kanpur">&nbsp;&nbsp; kanpur</label>
								<label class="checkbox-inline"><input type="checkbox" name="city[]"value="lucknow">&nbsp;&nbsp; lucknow</label>
								<label class="checkbox-inline"><input type="checkbox" name="city[]"value="patna">&nbsp;&nbsp; patna</label>
								<label class="checkbox-inline"><input type="checkbox" name="city[]"value="bengluru">&nbsp;&nbsp; bengluru</label>
							</div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Password *</p>
							  <input type="password" name="password" placeholder="password" required >
							</div>
						
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							<p>Role *</p>
								<select name='role' class='selectboxcss'>
									<?php  
										while($row_list=mysqli_fetch_assoc($result)){ ?>  
										<option value="<?php echo $row_list['id']; ?>">
											<?php echo $row_list['role'];?>  
										</option>  
									<?php } ?>  
								</select>
							</div>
						</div>
						
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
							  <p>Address *</p>
							  <textarea type="textarea" name="address" rows="4" cols="100" placeholder="Address" required ></textarea>
							</div>
						</div>
						
						<div class="row">	
							<div class="col-lg-6 col-md-6 col-sm-6 comment-form-comment">
							  <input type="submit" name='login' value="SignUp" />
							</div>
						</div>
                    </form>
					<br>
					
					
                  </div>
                
                <!-- single-blog end -->
              </div>
            </div> 
          
        </div>
      </div>
    

<?php require"footer.php"; ?>