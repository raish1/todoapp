<?php
require"db.php";
$user_id="";
	$user_id=$_POST['id'];
	$sql="Delete FROM user where id='".$user_id."'";
	if(mysqli_query($conn,$sql)){
		//header("location: index.php");
		echo "success";
	}else{
		echo "error deleting record".mysqli_error($conn);
	}
	mysqli_close($conn); 
?>
