<?php 
require"header.php";
$result="";
if(isset($_POST['submit'])){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$to_email = "raishalam043@gmail.com";
	$subject = $_POST["subject"];
	$message = $_POST["message"];
	$headers = "From: $email";
	$send = mail($email,$subject,$message,$headers);
    if(!$send){
	  $result="Email sending failed...";
    }else{
		$result="Email sent.";
	}
	//echo $name." ".$email;
	
}
 ?>

<!-- ======= Contact Section ======= -->
    <div id="contact" class="contact-area">
      <div class="contact-inner area-padding">
        <div class="contact-overly"></div>
        <div class="container ">
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
				<br>
              <div class="section-headline text-center">
                <h2>Contact us</h2>
              </div>
            </div>
          </div>
          <div class="row">
            <!-- Start contact icon column -->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="fa fa-mobile"></i>
                  <p>
                    Call: +91 8882672846<br>
                    <span>Monday-Friday (9am-5pm)</span>
                  </p>
                </div>
              </div>
            </div>
            <!-- Start contact icon column -->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="fa fa-envelope-o"></i>
                  <p>
                    Email: info@innogenx.in<br>
                    <span>Web: https://innogenx.in/</span>
                  </p>
                </div>
              </div>
            </div>
            <!-- Start contact icon column -->
            <div class="col-md-4 col-sm-4 col-xs-12">
              <div class="contact-icon text-center">
                <div class="single-icon">
                  <i class="fa fa-map-marker"></i>
                  <p>
                    Location: InnogenX, 4th Floor , 
					Uma Admiralty, No.1, HDFC Bank, 
					Bannerghatta Main Rd, BTM Layout 1, 
					<br>
                    <span>Bengaluru, Karnataka 560029</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="row">

            <!-- Start Google Map -->
            <div class="col-md-12 col-sm-12 col-xs-12">
              <!-- Start Map -->
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.7689505079043!2d77.59817551388231!3d12.922566290888026!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15c1b9eb699f%3A0xbc5c67a2d6972e66!2sInnogenx!5e0!3m2!1sen!2sin!4v1602239199098!5m2!1sen!2sin" width="600" <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.7689505079043!2d77.59817551388231!3d12.922566290888026!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae15c1b9eb699f%3A0xbc5c67a2d6972e66!2sInnogenx!5e0!3m2!1sen!2sin!4v1602239199098!5m2!1sen!2sin" width="100%" height="380" frameborder="0" style="border:0" allowfullscreen></iframe>
              <!-- End Map -->
            </div>
			</div>
			 <!-- End Google Map -->
			 <br/>
			 <br/>
			<div class="row">
            <!-- Start  contact -->
            <div class="col-md-8 col-sm-8 col-lg-12 col-xs-12">
              <div class="form contact-form">
                <form action="contact.php" method="post" role="form" class="">
                  <div class="form-group">
                    <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                    <div class="validate"></div>
                  </div>
                  <div class="form-group">
                    <input type="email" class="form-control" name="email" id="email_send" placeholder="Your Email" data-rule="email" data-msg="Please enter a valid email" />
                    <div class="validate"></div>
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Subject" data-rule="minlen:4" data-msg="Please enter at least 8 chars of subject" />
                    <div class="validate"></div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" name="message" rows="5" data-rule="required" data-msg="Please write something for us" placeholder="Message"></textarea>
                    <div class="validate"></div>
                  </div>
                  
                  <div class="text-center"><input type="submit" name='submit' value="send" /></div>
				  
                </form>
              </div>
			  <?php if($result!=''){?>
				<div class="alert alert-success" role="alert"><?php echo $result;?></div>
			  <?php } ?>
			</div>
            <!-- End Left contact -->
          </div>
        </div>
      </div>
    </div><!-- End Contact Section -->
<?php require"footer.php"; ?>