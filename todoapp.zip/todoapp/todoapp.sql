-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 15, 2021 at 07:32 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `todoapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `name`) VALUES
(1, 'Development'),
(2, 'Design'),
(3, 'e-commerce'),
(4, 'Digital Marketing'),
(5, 'Sales');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `department` int(11) NOT NULL,
  `city` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `mobile`, `gender`, `department`, `city`, `address`, `password`, `role`, `created_date`) VALUES
(1, 'Raish Alam', 'raishalam043@gmail.com', '08882672846', 'male', 3, 'kanpur', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 2, '2021-05-06 07:52:51'),
(2, 'Raish Alam', 'h@gmail.com', '08882672846', 'male', 2, 'kanpur,lucknow,patna,bengluru', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 2, '2021-05-06 08:27:54'),
(3, 'Raish ', 'abc@gmail.com', '08882672846', 'male', 5, 'lucknow', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 1, '2021-05-06 09:01:02'),
(5, 'Raish Alam', 'aaa@gmail.com', '08882672846', 'male', 1, 'kanpur', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 2, '2021-05-07 19:35:40'),
(6, 'hello12345', 'abcd12345@gmail.com', '08882672444', 'female', 2, 'lucknow,bengluru', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 1, '2021-05-10 04:49:35'),
(7, 'testhello', 'ttt@gmail.com', '08882672846', 'male', 1, 'kanpur,lucknow', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 1, '2021-05-10 19:40:11'),
(8, 'raish11', 'alam444@gmail.com', '08882672845', 'female', 2, 'kanpur,lucknow,patna,bengluru', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n123456', 'MTIzNDU=', 2, '2021-05-10 19:48:13'),
(9, 'abcd', 'abcdef12312@gmail.com', '08882672846', 'female', 3, 'kanpur,lucknow,patna,bengluru', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 2, '2021-05-10 21:33:58'),
(10, 'rafik khan11112ergetest', 'rafik11@gmail.com', '08882672444', 'male', 4, 'patna,bengluru', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n1333333333\r\n', 'MTIz', 2, '2021-05-10 21:46:02'),
(11, 'hello php test', 'b@gmail.com', '08882672846', 'male', 2, 'kanpur,lucknow', '#35 , Pentecost central Church Mangammanapalya Main Rd, Popular Colony, HSR Layout, Bengaluru, Karnataka 560068\r\n', 'MTIzNDU=', 2, '2021-05-12 09:06:43');

-- --------------------------------------------------------

--
-- Table structure for table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'admin'),
(2, 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
