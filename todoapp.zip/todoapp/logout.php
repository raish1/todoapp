<?php
session_start();
$_SESSION['name']='';
header("location: index.php");
?>