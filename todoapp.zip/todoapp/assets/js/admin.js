$(document).ready(function() {

	$("#email").blur(function() {
		var email = $(this).val();
		var res_Available = "<span style='color: green;'>Available.</span>";
		
		if(email != ''){
			$.ajax({
				url: 'function.php',
				type: 'post',
				data: {email: email},
				success: function(response){
					if(response!='Available.'){ 
						$('#email').val('');//print user email//
						$('#email_response').html("<span style='color: red;'>"+email +" - "+ "Not Available.</span>");
					}else{
						$('#email_response').html(res_Available);
					}
				}
			});
		}else{
			$("#email_response").html("");
		}
	});
	
	
	var url = window.location.href;
    
    $('.nav-menu a').each(function () {
        var linkPage = this.href;

        if (url == linkPage) {
            $(this).closest("li").addClass("active");
        }
    });
	
	
	
	$(".deleteUser").click(function(){
		if (confirm('Are you sure to delete?')) {
			var id = $(this).attr('id');
			$.ajax({
				url: "delete.php",
				type: "POST",
				data: {'id':id},
				cache: false,
				success: function (data) {
					alert("User deleted with id: "+id);
					location.reload();
				}
			});
			
		}
	}); 
	
});