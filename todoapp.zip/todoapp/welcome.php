<?php 
//session_start();
require"header.php"; 
require"db.php"; 

?>

 
    <!-- ======= Blog Page ======= -->
    <div class="blog-page area-padding">
      <div class="container">
        <div class="row">
        
              <div class="col-md-12 col-sm-12 col-xs-12">
                 <div class="comment-respond">
                    <h3 class="comment-reply-title">Hello -  <?php echo $_SESSION['name'];?> !!</h3>
					 <table class="table">
						  <thead>
							<tr>
							  <th scope="col">Name</th>
							  <th scope="col">Mobile</th>
							  <th scope="col">Address</th>
							  <th scope="col">Role</th>
							  <th scope="col"></th>
							</tr>
						  </thead>
					<tbody>
					
				     <?php 
						$email=$_SESSION['email'];
						$sql="SELECT role FROM user Where email='$email'";
						$data=mysqli_query($conn,$sql);
						$result = mysqli_fetch_assoc($data);
						$role_id = $result['role'];
						
						if($role_id== 1){
							$sql_user = "SELECT id,name,mobile,address,role FROM user Where role=2";
							$data_user = mysqli_query($conn,$sql_user);
							while($result_user = mysqli_fetch_array($data_user)){						
					?>
							<tr>
								<td><?php echo $result_user['name'];?></td>
								<td><?php echo $result_user['mobile'];?></td>
								<td><?php echo $result_user['address'];?></td>
								<td>User</td>
								<td><button class='deleteUser' id="<?php echo $result_user['id'];?>">Delete</button></td>
							</tr>
					<?php }
						}else{
						$sql_user = "SELECT id,name,mobile,address,role FROM user Where email='$email'";
						$data_user = mysqli_query($conn,$sql_user);
						$result_user = mysqli_fetch_assoc($data_user);
					?>		  
						<tr>
							<td><?php echo $result_user['name'];?></td>
							<td><?php echo $result_user['mobile'];?></td>
							<td><?php echo $result_user['address'];?></td>
							<td>User</td>
							<td><a href="editUser.php?user_id=<?php echo $result_user['id'];?>"/>EDIT</a></td>
						</tr>
					<?php }?>		  	
					</tbody>
					</table>
                 </div>
                
                <!-- single-blog end -->
              </div>
            </div>
          </div>
        
    </div><!-- End Blog Page -->
	
<?php require"footer.php"; ?>