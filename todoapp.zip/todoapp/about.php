<?php require"header.php"; ?>

<!-- ======= About Section ======= -->
    <div id="about" class="about-area area-padding">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
		  <br>
            <div class="section-headline text-center">
              <h2>ABOUT INNOGENX</h2>
            </div>
          </div>
        </div>
        <div class="row">
          
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="well-middle">
              <div class="single-well">
                
                <p>
                  Disciplined, driven by passion, and daring. It is how we would like to define our team at Innogenx.
                </p>
                <p>
				<h2>Disciplined</h2>
				Step by step, we help your business climb up the ladder of success. When it comes to SEO and content marketing, discipline matters. We carve a success story for our clients by putting in consistent efforts,
				</p>
				<p>
				<h2>Passionate</h2>
				We are passionate and driven to get results for our clients.
				</p>
				<p>
				<h2>Daring</h2>
				We go all out to bring our video presentations to life and make our client’s brand stand out from their competitors with our digital marketing.As real partners to our customers, we solve their problems. Our designers, content writers, developers, and strategists are collaborative, committed, and passionate about their work. Silicon Valley of India, Bangalore, is the place where we are situated. We welcome you to come and join us on a drive towards success and growth.
                </p>
                
              </div>
            </div>
          </div>
          <!-- End col-->
        </div>
      </div>
    </div><!-- End About Section -->


<?php require"footer.php"; ?>